unsigned int ModRTU_CRC(unsigned char[], int);
